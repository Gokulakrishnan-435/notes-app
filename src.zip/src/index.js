import React from 'react';
import ReactDOM from 'react-dom'
import App from './App';
import GalleryProvider from './ContextApi/Gallery';
import './index.css'

ReactDOM.render(<GalleryProvider><App/></GalleryProvider>,document.getElementById('root'))